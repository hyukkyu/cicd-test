import json
import os
import boto3
from datetime import datetime

secrets_manager = boto3.client('secretsmanager')
comprehend = boto3.client('comprehend')
rekognition = boto3.client('rekognition')
sns = boto3.client('sns')
sqs = boto3.client('sqs')

MODERATION_THRESHOLD = float(os.getenv('MODERATION_THRESHOLD', '0.8'))
SNS_TOPIC_ARN = os.getenv('CMS_COMMUNITY_SNS_TOPIC')


def fetch_secret(secret_name):
    response = secrets_manager.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])


def lambda_handler(event, context):
    """Entry point for SQS triggered moderation pipeline."""
    results = []
    for record in event.get('Records', []):
        body = json.loads(record['body'])
        post = body['post']
        text = post.get('content', '')
        media_bucket = body.get('mediaBucket')
        media_key = body.get('mediaKey')
        text_score = detect_text_toxicity(text)
        media_score = detect_media_toxicity(media_bucket, media_key) if media_bucket and media_key else 0
        blocked = text_score > MODERATION_THRESHOLD or media_score > 90
        result = {
            'postId': post['id'],
            'textScore': text_score,
            'mediaScore': media_score,
            'blocked': blocked,
            'evaluatedAt': datetime.utcnow().isoformat(),
        }
        results.append(result)
        if SNS_TOPIC_ARN:
            sns.publish(TopicArn=SNS_TOPIC_ARN, Message=json.dumps(result))
    return {'processed': len(results), 'results': results}


def detect_text_toxicity(text):
    if not text:
        return 0
    response = comprehend.detect_sentiment(Text=text, LanguageCode='ko')
    return response['SentimentScore']['Negative']


def detect_media_toxicity(bucket, key):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=bucket, Key=key)
    image_bytes = obj['Body'].read()
    response = rekognition.detect_moderation_labels(
        Image={'Bytes': image_bytes},
        MinConfidence=70,
    )
    if not response['ModerationLabels']:
        return 0
    return max(label['Confidence'] for label in response['ModerationLabels'])
